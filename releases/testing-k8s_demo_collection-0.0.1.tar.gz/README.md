K8s Collection
--------------
--------------

Simple collection containing the Ansible K8s modules.

